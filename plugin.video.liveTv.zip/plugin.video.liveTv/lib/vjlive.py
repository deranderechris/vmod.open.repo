# -*- coding: utf-8 -*-

import json as jsonmod
import xbmcvfs
import xbmcgui
import xbmcplugin
import re
from urllib import parse
import urllib.request as ur
import time
import xbmc
import os
import sys
import xbmcaddon
import requests
import utils

DEBUG = os.path.exists(xbmcvfs.translatePath('special://home/debug'))
addonID = 'plugin.video.liveTv'

flagPath = 'special://home/addons/plugin.video.liveTv/'

# globale Struktur:
# groups = {
#   "Germany": {
#       "RTL": [ item1, item2, ... ],
#       "ZDF": [ item3, ... ],
#   },
#   "Austria": { ... }
# }
groups = {}

VAVOO_CATALOG_URL = "https://vavoo.to/vto-cluster/mediahubmx-catalog.json"
VAVOO_RESOLVE_URL = "https://vavoo.to/vto-cluster/mediahubmx-resolve.json"

def _get_vavoo_headers():
    return {
        "accept-encoding": "gzip",
        "user-agent": "MediaHubMX/2",
        "accept": "application/json",
        "content-type": "application/json; charset=utf-8",
        "mediahubmx-signature": utils.getAuthSignature()
    }

def _fetch_vavoo_catalog():
    """
    Holt alle Kanäle aus dem neuen Vavoo-Katalog (vto-iptv)
    und baut die globale groups-Struktur wie vorher aus live2.
    """
    global groups
    groups = {}

    cursor = 0
    while True:
        payload = {
            "language": "de",
            "region": "AT",
            "catalogId": "vto-iptv",
            "id": "vto-iptv",
            "adult": False,
            "search": "",
            "sort": "name",
            "filter": {},
            "cursor": cursor,
            "clientVersion": "3.0.2"
        }

        r = requests.post(
            VAVOO_CATALOG_URL,
            data=jsonmod.dumps(payload),
            headers=_get_vavoo_headers(),
            timeout=10
        )
        r.raise_for_status()
        data = r.json()

        items = data.get("items", [])
        for item in items:
            group = item.get("group") or "Other"
            name = item.get("name") or "Unknown"

            # optional: Name bereinigen wie früher
            name = re.sub(r'( (SD|HD|FHD|UHD|H265))?( \(BACKUP\))? \(\d+\)$', '', name)

            if group not in groups:
                groups[group] = {}
            g = groups[group]
            if name not in g:
                g[name] = []
            g[name].append(item)

        next_cursor = data.get("nextCursor")
        if not next_cursor:
            break
        cursor = next_cursor

class Player(xbmc.Player):
    pass

def convertPluginParams(params):
    p = []
    for key, value in params.items():
        if isinstance(value, str):
            value = value.encode('utf-8')
        p.append(parse.urlencode({key: value}))
    return '&'.join(sorted(p))

def getPluginUrl(params):
    return 'plugin://' + addonID + '/?' + convertPluginParams(params)

def _resolve_vavoo_url(url):
    """
    Wandelt eine Vavoo-URL über mediahubmx-resolve in eine echte Stream-URL um.
    """
    payload = {
        "language": "de",
        "region": "AT",
        "url": url,
        "clientVersion": "3.0.2"
    }
    r = requests.post(
        VAVOO_RESOLVE_URL,
        data=jsonmod.dumps(payload),
        headers=_get_vavoo_headers(),
        timeout=10
    )
    r.raise_for_status()
    data = r.json()
    # laut michaz: data[0]["url"]
    if isinstance(data, list) and data:
        return data[0].get("url")
    raise ValueError("Konnte Stream-URL nicht auflösen")

def livePlay(action, groups, group, name):
    # group und name kommen als bytes (wegen encode in URL)
    if isinstance(group, bytes):
        group = group.decode('utf-8')
    if isinstance(name, bytes):
        name = name.decode('utf-8')

    try:
        m = groups[group][name]
        m[0]
    except (IndexError, KeyError):
        xbmcgui.Dialog().ok('Der Kanal ist nicht verfügbar', 'Bitte versuche es später erneut.')
        return

    # mehrere Streams? Auswahl
    if len(m) > 1 or DEBUG:
        captions = list(sorted([n['name'] for n in m]))
        index = xbmcgui.Dialog().select('Stream wählen', captions)
        if index < 0:
            raise ValueError('CANCELED')
        n = m[index]
    else:
        n = m[0]

    progress = xbmcgui.DialogProgress()
    try:
        progress.create('Viel Spass mit LiveTV', u'Der Stream wird gestartet...')
        progress.update(5)

        # URL über neue API auflösen
        try:
            stream_url = _resolve_vavoo_url(n['url'])
        except Exception:
            xbmcgui.Dialog().ok('Der Kanal ist nicht verfügbar', 'Stream konnte nicht aufgelöst werden.')
            return

        o = xbmcgui.ListItem()
        o.setInfo('Video', {'title': n['name'], 'Seekable': 'false', 'SeekEnabled': 'false'})
        o.setLabel(n['name'])
        o.setPath(stream_url)
        o.setProperty('IsPlayable', 'true')
        o.setProperty('IsNotSeekable', 'true')
        o.setProperty('Seekable', 'false')
        o.setProperty('SeekEnabled', 'false')

        progress.update(15)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, o)
        progress.update(20)

        abortReason = ''
        step = 1
        t = time.time()
        player = Player()
        try:
            while not abortReason:
                if progress.iscanceled():
                    abortReason = 'cancelled'
                elif time.time() - t > 15:
                    abortReason = 'timeout'
                elif step == 1:
                    if player.isPlaying():
                        progress.update(30)
                        step = 2
                if step == 2:
                    if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                        progress.update(45)
                        step = 3
                if step == 3:
                    if player.getTime() > 0.01:
                        progress.update(100)
                        xbmcgui.Dialog().notification('', 'Viel Spass mit LiveTV', xbmcgui.NOTIFICATION_INFO, 2000, False)
                        break
                if not abortReason:
                    xbmc.sleep(15)
            if abortReason:
                player.stop()
                xbmcgui.Dialog().ok('Der Kanal ist nicht verfügbar', 'Bitte versuche es später erneut.')
        finally:
            del player
    finally:
        if progress:
            progress.close()
            del progress

def liveGroupIndex(action, groups, group):
    if isinstance(group, bytes):
        group = group.decode('utf-8')

    g = groups.get(group, {})
    for name, m in sorted(g.items()):
        name_str = name.strip()
        url = getPluginUrl({'action': action, 'group': group.encode('utf-8'), 'name': name_str.encode('utf-8')})

        logo = None
        for n in m:
            if n.get('logo'):
                logo = n['logo']
                break

        o = xbmcgui.ListItem(name_str)
        if logo:
            o.setArt({"icon": 'special://home/addons/plugin.video.liveTv/flags/channel.png', "thumb": logo})
        else:
            o.setArt({"icon": 'special://home/addons/plugin.video.liveTv/flags/channel.png'})

        o.setInfo(type='Video', infoLabels={'Title': name_str})
        o.setProperty('IsPlayable', 'true')
        o.setProperty('selectaction', 'play')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=o, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)

def liveIndex(action, groups):
    LIVE_GROUP_ALIASES = (
        (u'Germany', u'Deutschland', 'flags/country/de.png', None),
        (u'Germany/Sky', u'SKY Deutschland', 'flags/country/de.png', None),
        (u'DE2', u'Deutschland#2', 'flags/country/de.png', None),
        (u'Turkey', u'Türkei', 'flags/country/tr.png', None),
        (u'Netherlands', u'Niederlande', 'flags/country/nl.png', None),
        (u'Italy', u'Italien', 'flags/country/it.png', None),
        (u'France', u'Frankreich', 'flags/country/fr.png', None),
        (u'United Kingdom', u'England', 'flags/country/en.png', None),
        (u'Spain', u'Spanien', 'flags/country/es.png', None),
        (u'Balkans', u'Balkan', 'flags/country/yu.png', None),
        (u'Switzerland', u'Schweiz', 'flags/country/ch.png', None),
        (u'Austria', u'Austria', 'flags/country/at.png', None),
        (u'Portugal', u'Portugal', 'flags/country/pt.png', None),
        (u'Poland', u'Polen', 'flags/country/pl.png', None),
        (u'Ukraine', u'Ukraine', 'flags/country/ua.png', None),
        (u'Belgium', u'Belgien', 'flags/country/be.png', None),
        (u'Finland', u'Finland', 'flags/country/fi.png', None),
        (u'Sweden', u'Schweden', 'flags/country/se.png', None),
        (u'Denmark', u'Dänemark', 'flags/country/dk.png', None),
        (u'Norway', u'Norwegen', 'flags/country/no.png', None),
        (u'Scandinavia', u'Skandinavien', 'flags/country/scd.jpg', None),
        (u'Czech Republic', u'Tschechien', 'flags/country/cz.png', None),
        (u'Serbia', u'Serbien', 'flags/country/rs.png', None),
        (u'Slovenia', u'Slovenien', 'flags/country/si.png', None),
        (u'Bulgaria', u'Bulgarien', 'flags/country/bg.png', None),
        (u'Romania', u'Rumänien', 'flags/country/ro.png', None),
        (u'Greece', u'Griechenland', 'flags/country/gr.png', None),
        (u'Macedonia', u'Makedonien', 'flags/country/mk.png', None),
        (u'Estonia', u'Estland', 'flags/country/ee.png', None),
        (u'Hungary', u'Ungarn', 'flags/country/hu.png', None),
        (u'Lithuania', u'Litauen', 'flags/country/lt.png', None),
        (u'Lithunia', u'Litauen', 'flags/country/li.png', None),
        (u'Malta', u'Malta', 'flags/country/mt.png', None),
        (u'Albania', u'Albanien', 'flags/country/al.png', None),
        (u'Russia', u'Russland', 'flags/country/ru.png', None),
        (u'Israel', u'Israel', 'flags/country/il.png', None),
        (u'USA', u'USA', 'flags/country/us.png', None),
        (u'Canada', u'Kanada', 'flags/country/ca.png', None),
        (u'Brazil', u'Brasilien', 'flags/country/br.png', None),
        (u'Columbia', u'Kolumbien', 'flags/country/co.png', None),
        (u'Latin', u'Lateinamerika', 'flags/country/latin.jpg', None),
        (u'Armenia', u'Armenien', 'flags/country/am.png', None),
        (u'Armenian', u'Armenien#2', 'flags/country/am.png', None),
        (u'Arabia', u'Arabisch', 'flags/country/ae.png', None),
        (u'Azerbaijan', u'Azerbaijan', 'flags/country/az.png', None),
        (u'Iran', u'Iran', 'flags/country/ir.png', None),
        (u'Afganisthan', u'Afghanistan', 'flags/country/af.png', None),
        (u'Afghanistan', u'Afghanistan#2', 'flags/country/af.png', None),
        (u'Kurdish', u'Kurdistan', 'flags/country/kur.png', None),
        (u'India', u'Indien', 'flags/country/in.png', None),
        (u'Pakistan', u'Pakistan', 'flags/country/pk.png', None),
        (u'Africa', u'Afrika', 'flags/country/afr.png', None),
        (u'Afrika', u'Afrika#2', 'flags/country/afr.png', None),
        (u'Seychelles', u'Seychellen', 'flags/country/sc.png', None),
        (u'Suriname', u'Suriname', 'flags/country/sr.png', None),
        (u'China', u'China', 'flags/country/cn.png', None),
        (u'Korea', u'Korea', 'flags/country/kr.png', None),
        (u'Japan', u'Japan', 'flags/country/jp.png', None),
        (u'Thailand', u'Thailand', 'flags/country/th.png', None),
        (u'Malaysia', u'Malaysia', 'flags/country/my.png', None),
        (u'Nauru', u'Nauru', 'flags/country/nr.png', None),
        (u'Philippines', u'Philippinen', 'flags/country/ph.png', None),
        (u'Singapore', u'Singapur', 'flags/country/sg.png', None),
        (u'Viet Nam', u'Vietnam', 'flags/country/vn.png', None),
        (u'SKAI DIGITAL', u'SKAI DIGITAL', 'flags/country/skai.png', None),
        (u'SPORTS', u'SPORTS', 'flags/country/wsp.jpg', None),
        (u'SPORTS 2', u'SPORTS 2', 'flags/country/wsp.jpg', None),
        (u'Indonesia', u'Indonesia', 'flags/country/Indonesia.png', None),
        (u'XXX', u'XXX', 'flags/country/skai.png', None)
    )

    index = []
    for group, g in groups.items():
        for i, (alias, name, icon, url) in enumerate(LIVE_GROUP_ALIASES):
            if alias == group:
                title = name
                break
        else:
            i, title, icon, url = (99999, group, 'special://home/addons/plugin.video.liveTv/flags/channel.png', None)

        if url is None:
            url = getPluginUrl({'action': action, 'group': group.encode('utf-8')})

        index.append((i, title.strip() + u' (' + str(len(g)) + u' Kanäle)', xbmcvfs.translatePath(flagPath + icon), url))

    for i, title, icon, url in sorted(index):
        o = xbmcgui.ListItem(title)
        o.setArt({"icon": icon, "thumb": icon})
        o.setInfo(type='Video', infoLabels={'Title': title})
        o.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=o, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)

def list_categories(params):
    action = params.get('action', '')

    # Lazy load: erst hier Vavoo-Kanäle holen
    if not groups:
        _fetch_vavoo_catalog()

    group = params.get('group')
    name = params.get('name')

    if group and name:
        livePlay(action, groups, group, name)
    elif group:
        liveGroupIndex(action, groups, group)
    else:
        liveIndex(action, groups)

def begin(paramstring):
    params = dict(parse.parse_qsl(paramstring))
    list_categories(params)

def vmod():
    begin(sys.argv[2][1:])
